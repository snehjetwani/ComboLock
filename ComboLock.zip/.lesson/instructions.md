# Introduction
In this assignment, we will be creating a combination lock object that can be used to create digital locks that can be opened with the correct sequence of operations. You must also create a class to run and test the ComboLock class and it must pass all Junit tests in ComboLockTest.java.

# Assignment
Your assignment is to create a class that represents a combination lock. It will have have four required instance variables representing the three required numbers to open the lock and a password in case you forget your numbers. You will implement the methods to turn the lock to the right and to the left and you will need a method to check to see if they have unlocked the lock. There will be a fail safe method that will allow the user to retrieve their combo with a password in case they cannot remember their combination. 

## Specification: 
Create a class called ComboLock. 
- Provide the following required instance variables (they should be declared private!):
  - int secretOne
  - int secretTwo
  - int secretThree
  - String password
- Three constructors
  - First constructor should take one parameter: String password. Set all three numbers to unique integers randomly (no repeat numbers) between 1-60.
  - Second constructor should take three parameters: int secretOne, int secretTwo, int secretThree. Set the password to null (they cannot use a password to retrieve the numbers)
  - Third constructor should take all four parameters: int secretOne, int secretTwo, int secretThree, String password
- The following public methods:
  - public void turnRight(int number): turns the combination lock to the right and sets it to the number passed.
  - public void turnLeft(int number): turns the combination lock to the left and sets it to the number passed. 
  - public Boolean isOpen(): return True if the user turned the lock to the right to secretOne, then to the left to secretTwo then finally right to secretThree. If they do not do those three in order to the proper numbers, it should return false. 
  - public int[] forgotNumbers(String passwordGuess): If the password is equal to the passwordGuess then return an integer array containing the combo, otherwise return null. If the password is null this will always return null.

Create another class called ComboLockRun.
- The program should have a main function that will ask the user what they would like to do, give them four options:  
  - Turn the lock to the right to a number.
  - Turn the lock to the left to a number.
  - Open the lock 
  - Retrieve the combination
- Your test class should create a combo lock using only a password (so it sets the combo to three random numbers). That way the user has to retrieve the combination and then enter it properly. If the lock is open it should print a message saying "The lock was opened" and if it is not open it should say "The lock remains locked". You can hard code the password in a constant in the ComboLockRun.java. 
- Make sure the retrieve the combination option prints out the combination in a user readable format.

Make sure your code passes all the unit tests before submitting.