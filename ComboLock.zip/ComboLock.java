import java.util.ArrayList;
import java.util.Arrays;
public class ComboLock{
//Create your ComboLock class here, make sure the Main file can do everything ComboLock Run is supposed to do and that this passes all of the unit tests.  
//Instance Variables
private int secretOne;
private int secretTwo;
private int secretThree;
private String password;
// First constructor takes one parameter
public ComboLock(String password){
  this.password=password;
  int min = 1;
  int max = 60;
  int secretOne = (int)Math.floor(Math.random()*(max-min+1)+min);
  int secretTwo = (int)Math.floor(Math.random()*(max-min+1)+min);
  int secretThree = (int)Math.floor(Math.random()*(max-min+1)+min);
  while (this.secretOne == this.secretTwo || this.secretTwo == this.secretThree || this.secretOne == this.secretThree){
    this.secretOne = (int)Math.floor(Math.random()*(max-min+1)+min);
    this.secretTwo = (int)Math.floor(Math.random()*(max-min+1)+min);
    this.secretThree = (int)Math.floor(Math.random()*(max-min+1)+min);
  }
}
//Second constructor takes three parameters
public ComboLock(int secretOne, int secretTwo, int secretThree){
  this.secretOne = secretOne;
  this.secretTwo = secretTwo;
  this.secretThree = secretThree;
  this.password = null;
}
//Third constructor takes all 4 parameters
public ComboLock(int secretOne, int secretTwo, int secretThree, String password){
  this.secretOne = secretOne;
  this.secretTwo = secretTwo;
  this.secretThree = secretThree;
  this.password = password;
}
//Setting up arrays for combos and directions
ArrayList<Integer> ArrayInteger = new ArrayList<>(Arrays.asList(0,0,0));
ArrayList<String> ArrayString = new ArrayList<>(Arrays.asList("blank","blank","blank"));
//Moves lock right to a desired number
public void turnRight(int number){
  ArrayInteger.add(number);
  ArrayInteger.remove(0);
  ArrayString.add("right");
  ArrayString.remove(0);
}
//Moves lock left to a desired number
public void turnLeft(int number){
  ArrayInteger.add(number);
  ArrayInteger.remove(0);
  ArrayString.add("left");
  ArrayString.remove(0);
}
//If all 3 numbers are right, and turned in the right order, combo lock opens, else it remains closed
public boolean isOpen(){
  return (this.secretOne == ArrayInteger.get(0) && ArrayString.get(0) == "right" && this.secretTwo == ArrayInteger.get(1) && ArrayString.get(1) == "left" && this.secretThree == ArrayInteger.get(2)  && ArrayString.get(2) == "right");
}
//If the password entered by the user is right, they can see their combo, but if it's wrong, null is returned.
public int[] forgotNumbers(String passwordGuess){
  if (this.password.equals(passwordGuess)){
    int[] array = {this.secretOne, this.secretTwo, this.secretThree};
    return array;}
    else{
      return null;
    }
  }
}