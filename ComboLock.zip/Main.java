class Main {
  public static void main(String[] args) {

    //tests

    ComboLock lockOne = new ComboLock(1,2,3);
    ComboLock lockTwo = new ComboLock(4,5,6);
    
    lockOne.turnRight(1);
    lockOne.turnLeft(2);
    lockOne.turnRight(3);
    
    if(lockOne.isOpen()){
      System.out.println("Open");
    }else{
      System.out.println("Closed");
    }

    System.out.print("\n");
    
    lockTwo.turnRight(4);
    lockTwo.turnLeft(5);
    lockTwo.turnRight(7);
    
    if(lockTwo.isOpen()){
      System.out.println("Open");
    }else{
      System.out.println("Closed");
    }
  }
}